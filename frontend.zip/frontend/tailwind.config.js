/** @type {import('tailwindcss').Config} */
export default {
	content: [
		"./index.html",
		"./src/**/*.{js,ts,jsx,tsx}",
	],
	theme: {
		extend: {
			fontFamily: {
				palanquin: ['Palanquin', 'sans-serif'],
			},

			colors: {
				// 🌙 **Dark Mode Colors**
				background: "#0b0f19", 		// Deep navy black (Dark theme BG)
				base: "#161b2e", 			// Dark grey-blue for UI elements
				neutral: "#1f253e", 		// Muted dark blue-grey for dividers/borders
				accent: "#6366f1", 		// **Royal Blue (for buttons, links)**
				"accent-hover": "#4f46e5", // Slightly darker blue for hover
				txt: "#e4e7ef", 			// **Soft white text (better readability)**
				"txt-muted": "#a5acc9", 	// Soft grey-blue for secondary text
				"txt-depressed": "#6b7280", // Muted grey for placeholders

				// 🌞 **Light Mode Colors**
				"light-bg": "#f9fafb", 		// Off-white with a slight blue tint
				"light-base": "#e5e7eb", 	// Light grey for UI components
				"light-neutral": "#cbd5e1", // Soft grey for dividers
				"light-txt": "#1f2937", 	// **Dark grey-blue for text**
				"light-txt-muted": "#4b5563",

				// 🎨 **Status Colors**
				success: "#22c55e", 	// Soft green for success messages
				danger: "#ef4444", 		// Bright red for delete actions
				warning: "#facc15", 	// Gold yellow for warnings

				// 🎨 **Gradients**
				"gradient-start": "#4f46e5", // **Royal blue**
				"gradient-end": "#6366f1", 	// **Cooler vibrant blue**
			},

		},
	},
	plugins: [
		require('@tailwindcss/forms'),
	],
}

