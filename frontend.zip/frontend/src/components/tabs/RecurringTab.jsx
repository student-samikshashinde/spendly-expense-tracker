import React from 'react'

const RecurringTab = () => {
  return (
    <div>RecurringTab</div>
  )
}

export default RecurringTab