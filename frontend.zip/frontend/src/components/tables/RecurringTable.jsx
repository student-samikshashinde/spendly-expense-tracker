import React from 'react'

const recurringTable = () => {
  return (
    <div>recurringTable</div>
  )
}

export default recurringTable