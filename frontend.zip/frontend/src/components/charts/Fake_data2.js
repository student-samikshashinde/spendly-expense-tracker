export const pieData = {
  label: ["Expenditure", "Savings"],
  data: [200, 500] // Dummy values representing expenditure and savings/investment
};

export const amountByType = {
  food: 200,
  clothing: 800,
  transport: 500
}

// module.exports ={
//   pieData,
//   amountByType
// }